<script setup xmlns="http://www.w3.org/1999/html">
</script>

<template>
  <h1 class="display-1">Főoldal</h1>
  <div class="w-75 mt-5 m-auto p-5 bg-success bg-opacity-25">
    <h2>Vizsgaremek    </h2>
    <br>
    <h3> Számlázási Adatkezelő: Intelligens szoftver a hatékony számlázáshoz és kimutatásokhoz.</h3>
 <br>
    <h4>Készítették:</h4>
      <h5><ul>
        <li>Bakó Péter</li>
        <li>Schwarczenberger Ferenc</li>
      </ul></h5>
<br>
    <h4>Konzulens:</h4>
    <h5><ul>
      <li>Harangozó Zsolt</li>
    </ul></h5>
    2024
<br><br>

    Az aklalmazás használatához kérlek <a href="login">jelentkezz be</a>, vagy ha még nincs accountod, <a href="register">regisztrálj!!</a>

    <br><br>
    Ha szeretnéd felvenni velünk a kapcsolatot, válaszd a <a href="contact">kapcsolati form-ot!</a>
  </div>

</template>
