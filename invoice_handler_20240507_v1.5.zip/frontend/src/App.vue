<template>
  <nav-bar/>
  <RouterView />
</template>

<script setup>
import { RouterView } from 'vue-router';
import NavBar from "@/components/layouts/NavBar.vue";

</script>

<style scoped>

</style>
