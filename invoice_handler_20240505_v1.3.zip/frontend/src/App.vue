<script setup>
import { RouterView } from 'vue-router'
import NevBar from "@/components/layouts/NavBar.vue";
</script>

<template>
  <nev-bar/>
  <RouterView />
</template>

<style scoped>

</style>
