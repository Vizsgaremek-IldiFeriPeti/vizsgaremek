<script setup>
import {RouterLink, useRouter} from "vue-router";
const routes = useRouter().getRoutes();
</script>

<template>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <router-link to="/" class="navbar-brand" >Számlázási Adatkezelő</router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item" v-for="link in routes" :key="link.name">
            <router-link v-if="link.meta.navbar" :to="{name:link.name}" class="nav-link active" aria-current="page" >{{link.meta.title}}</router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<style scoped>

</style>