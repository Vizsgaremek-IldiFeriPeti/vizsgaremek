<script setup xmlns="http://www.w3.org/1999/html">
</script>

<template>
  <h2 class="display-10">Főoldal</h2>
  <div class="w-75 mt-5 m-auto p-5 bg-success bg-opacity-25">
    <h2>Vizsgaremek    </h2>
    <br>
    <h3> Számlázási Adatkezelő: Intelligens szoftver a hatékony számlázáshoz és kimutatásokhoz.</h3>
 <br>
    <h4>Készítették:</h4>
      <ul>
        <li><h5>Bakó Péter</h5></li>
        <li><h5>Schwarczenberger Ferenc</h5></li>
      </ul>
<br>
    <h4>Konzulens:</h4>
    <ul>
      <li><h5>Harangozó Zsolt</h5></li>
    </ul>
    2024
<br><br>

    Az aklalmazás használatához kérlek használd a felső menüsort!
    <br><br>
    Az adatok az <a href="http://127.0.0.1:8000/invoiceheads">admin</a> oldalon szerkeszthetők!

    <br><br>
    Ha szeretnéd felvenni velünk a kapcsolatot, válaszd a <a href="contact">kapcsolati form-ot!</a>
  </div>

</template>
